package com.example.calculator;

import java.util.Scanner;

public class app {
    public static void main(String[] args) {
        Calculator calculator = new Calculator();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.print("첫 번째 숫자를 입력하세요: ");
            int num1 = sc.nextInt();

            System.out.print("두 번째 숫자를 입력하세요: ");
            int num2 = sc.nextInt();

            System.out.print("사칙연산 기호를 입력하세요(+, -, *, /): ");
            char operator = sc.next().charAt(0);

            try {
                double result = calculator.calcualte(num1, num2, operator);
                System.out.println("결과: " + result);


                System.out.println("저장된 모든 결과: " + calculator.getResults());
            } catch (ArithmeticException | IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
            System.out.println("더 계산하시겠습니까? (exit 입력 시 종료)");
            String exitInput = sc.next();
                if (exitInput.equalsIgnoreCase("exit")) {
                    System.out.println("계산기를 종료합니다.");
                    break;
                }

            System.out.println("가장 먼저 저장된 데이터를 삭제하시겠습니까? (remove 입력 시 삭제)");
            String removeInput = sc.next();
            if (removeInput.equalsIgnoreCase("remove")) {
                calculator.removeFirstResult();
                System.out.println("가장 오래된 결과가 삭제되었습니다.");
            }
        }

        sc.close();
    }
}