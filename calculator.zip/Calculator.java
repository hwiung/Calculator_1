package com.example.calculator;

import java.util.ArrayList;
import java.util.List;

public class Calculator {

    private List<Double> results = new ArrayList<>();

    public double calcualte(int num1, int num2, char operator) {
        double result = 0;

        switch (operator) {
            case '+':
                result = num1 + num2;
                break;

            case  '-':
                result = num1 - num2;
                break;

            case  '*':
                result = num1 * num2;
                break;

            case  '/':
                if (num2 == 0) {
                    throw new ArithmeticException("나눗셈 연산에서 분모에 0이 입력될 수 없습니다.");
                }
                result = num1 / (double)num2;
                break;
            default:
                    throw new IllegalArgumentException("유효하지 않은 연산자입니다. (+, -, *, / 중 하나를 입력하세요)");
        }
        results.add(result);
        return result;
    }

public List<Double> getResults() {
        return new ArrayList<>(results);
}

public  void removeFirstResult() {
        if (!results.isEmpty()) {
            results.remove(0);
        } else {
            System.out.println("삭제할 데이터가 없습니다.");
        }
    }

}
